import { useState } from 'react';

// Custom hook: form logic shared by the Donor and Request screens.
// validate(values) returns an object of errors. An empty object means the form is valid.
export function useForm(initialValues, validate) {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});

  function setField(name, value) {
    setValues({ ...values, [name]: value });
    setErrors({ ...errors, [name]: undefined });
  }

  async function handleSubmit(onValid) {
    const newErrors = validate(values);
    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      await onValid(values);
      setValues(initialValues);
    }
  }

  return { values, errors, setField, handleSubmit };
}
