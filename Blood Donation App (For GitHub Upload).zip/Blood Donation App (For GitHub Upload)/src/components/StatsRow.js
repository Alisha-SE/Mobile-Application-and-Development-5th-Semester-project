import { useContext } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { BloodContext } from '../context/BloodContext';
import { colors, fonts } from '../styles';
import { getRequestStatus } from '../utils/requestStatus';

// Reads the context directly, so HomeScreen and StatsRow pass no data down.
function StatCard({ label }) {
  const { donors, requests } = useContext(BloodContext);
  const count = label === 'Donors' ? donors.length : requests.filter((request) => getRequestStatus(request) === 'open').length;

  return (
    <View style={styles.card}>
      <Text style={styles.count}>{count}</Text>
      <Text style={styles.label}>{label}</Text>
    </View>
  );
}

export default function StatsRow() {
  return (
    <View style={styles.row}>
      <StatCard label="Donors" />
      <StatCard label="Open Requests" />
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', gap: 12, marginTop: 12, paddingHorizontal: 16 },
  card: { flex: 1, backgroundColor: colors.soft, borderRadius: 16, paddingVertical: 12, alignItems: 'center' },
  count: { fontFamily: fonts.bold, fontSize: 32, color: colors.primaryDark },
  label: { fontFamily: fonts.regular, fontSize: 15, color: colors.muted },
});
