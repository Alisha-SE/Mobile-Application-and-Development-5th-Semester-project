import { StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, fonts } from '../styles';

export default function Field({ label, error, ...inputProps }) {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        accessibilityLabel={label}
        style={[styles.input, error && styles.inputError]}
        {...inputProps}
      />
      {error ? <Text style={styles.error}>{error}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: 12 },
  label: { fontFamily: fonts.semibold, fontSize: 14, color: colors.text, marginBottom: 6 },
  input: {
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    padding: 12,
    fontFamily: fonts.regular,
    fontSize: 15,
    color: colors.text,
  },
  inputError: { borderColor: colors.primary },
  error: { fontFamily: fonts.regular, fontSize: 13, color: colors.primaryDark, marginTop: 6 },
});
