import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { BLOOD_GROUPS } from '../utils/eligibility';
import { colors, fonts } from '../styles';

export default function GroupPicker({ label, value, onChange, error }) {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
      <View style={styles.row}>
        {BLOOD_GROUPS.map((group) => {
          const selected = group === value;
          return (
            <TouchableOpacity
              key={group}
              accessibilityRole="button"
              aria-selected={selected}
              onPress={() => onChange(group)}
              style={[styles.chip, selected ? styles.chipSelected : styles.chipIdle]}
            >
              <Text style={[styles.chipText, selected && styles.chipTextSelected]}>{group}</Text>
            </TouchableOpacity>
          );
        })}
      </View>
      {error ? <Text style={styles.error}>{error}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: 12 },
  label: { fontFamily: fonts.semibold, fontSize: 14, color: colors.text, marginBottom: 6 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    minHeight: 44,
    minWidth: 56,
    paddingHorizontal: 14,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  chipSelected: { backgroundColor: colors.primary },
  chipIdle: { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border },
  chipText: { fontFamily: fonts.semibold, fontSize: 15, color: colors.text },
  chipTextSelected: { color: colors.white },
  error: { fontFamily: fonts.regular, fontSize: 13, color: colors.primaryDark, marginTop: 6 },
});
