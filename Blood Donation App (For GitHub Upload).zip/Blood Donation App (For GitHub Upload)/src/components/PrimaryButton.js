import { StyleSheet, Text, TouchableOpacity } from 'react-native';
import { colors, fonts } from '../styles';

export default function PrimaryButton({ title, onPress }) {
  return (
    <TouchableOpacity accessibilityRole="button" onPress={onPress} style={styles.button}>
      <Text style={styles.text}>{title}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    padding: 14,
    minHeight: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: { fontFamily: fonts.semibold, fontSize: 16, color: colors.white },
});
