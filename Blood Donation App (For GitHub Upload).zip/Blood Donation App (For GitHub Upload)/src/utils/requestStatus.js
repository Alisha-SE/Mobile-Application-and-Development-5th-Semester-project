// Request lifecycle stays deliberately simple for this beginner project.
export function getRequestStatus(request) {
  return request.status === 'fulfilled' ? 'fulfilled' : 'open';
}

export function isOwnLocalRequest(request) {
  // Legacy records: sample r1 must never be treated as the current user's request.
  return request.origin === 'local' || (request.origin == null && request.id !== 'r1' && !/^r[1-9]$/.test(String(request.id)));
}

export function getMyRequests(requests) {
  return requests.filter(isOwnLocalRequest).sort((a, b) =>
    String(b.createdAt || b.id).localeCompare(String(a.createdAt || a.id))
  );
}

export function sortRequests(requests) {
  return [...requests].sort((a, b) => {
    const isUrgentOpen = (r) => getRequestStatus(r) === 'open' && r.urgent === true;
    return Number(isUrgentOpen(b)) - Number(isUrgentOpen(a));
  });
}

export function updateRequestStatusList(requests, requestId, newStatus, onlyOwn = false) {
  if (!['open', 'fulfilled'].includes(newStatus)) return requests;
  return requests.map((request) =>
    request.id === requestId && (!onlyOwn || isOwnLocalRequest(request))
      ? { ...request, status: newStatus }
      : request
  );
}
