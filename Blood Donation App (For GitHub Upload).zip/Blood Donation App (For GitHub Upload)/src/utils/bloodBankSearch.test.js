import test from 'node:test';
import assert from 'node:assert/strict';
import { filterBloodBanks } from './bloodBankSearch.js';
const sample = [
  {name:'Red Crescent Centre',city:'Islamabad',address:'H-8',type:'Blood centre'},
  {name:'Alpha Blood Center',city:'Rawalpindi',address:'Satellite Town',type:'Blood bank'},
];
test('all banks when no filters',()=>assert.equal(filterBloodBanks(sample).length,2));
test('search by name case insensitive',()=>assert.equal(filterBloodBanks(sample,'ALPHA').length,1));
test('filter Islamabad',()=>assert.equal(filterBloodBanks(sample,'','Islamabad').length,1));
test('search area',()=>assert.equal(filterBloodBanks(sample,'Satellite').length,1));
test('no matching centre',()=>assert.deepEqual(filterBloodBanks(sample,'zzz'),[]));
