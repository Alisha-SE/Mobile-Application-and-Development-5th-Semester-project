import test from 'node:test';
import assert from 'node:assert/strict';
import { buildRequestMessage } from './shareRequest.js';
test('sharing includes request blood group and hospital',()=>{
 const message=buildRequestMessage({patient:'Test Patient',group:'B+',units:'2',hospital:'Test Hospital',phone:'03001234567'});
 assert.match(message,/B\+/); assert.match(message,/Test Hospital/); assert.match(message,/03001234567/);
});
test('missing optional fields have safe fallback',()=>assert.match(buildRequestMessage({}),/Not specified/));
