// Search by hospital name, city or address; optionally select a city.
// Kept separate so the filter can be tested without running Expo.
export function filterHospitals(hospitals, searchText = '', city = 'All') {
  const query = searchText.trim().toLowerCase();

  return hospitals.filter((hospital) => {
    const matchesCity = city === 'All' || hospital.city === city;
    const searchable = `${hospital.name} ${hospital.city} ${hospital.address}`.toLowerCase();
    return matchesCity && searchable.includes(query);
  });
}
