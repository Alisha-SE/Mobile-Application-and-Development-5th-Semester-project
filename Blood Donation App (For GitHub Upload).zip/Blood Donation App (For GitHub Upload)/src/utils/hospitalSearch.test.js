import assert from 'node:assert/strict';
import test from 'node:test';
import { filterHospitals } from './hospitalSearch.js';

const hospitals = [
  { id: 'h1', name: 'Shifa Hospital', city: 'Islamabad', address: 'H-8/4 Islamabad' },
  { id: 'h2', name: 'Holy Family Hospital', city: 'Rawalpindi', address: 'Satellite Town Rawalpindi' },
  { id: 'h3', name: 'Maryam Memorial Hospital', city: 'Rawalpindi', address: 'Peshawar Road' },
];

test('without filters every hospital is shown', () => {
  assert.equal(filterHospitals(hospitals).length, 3);
});

test('search works regardless of uppercase or extra spaces', () => {
  assert.deepEqual(filterHospitals(hospitals, '  SHIFA  ').map((h) => h.id), ['h1']);
});

test('city filter selects only its own city', () => {
  assert.deepEqual(filterHospitals(hospitals, '', 'Rawalpindi').map((h) => h.id), ['h2', 'h3']);
});

test('both city and search are applied', () => {
  assert.deepEqual(filterHospitals(hospitals, 'maryam', 'Rawalpindi').map((h) => h.id), ['h3']);
  assert.deepEqual(filterHospitals(hospitals, 'maryam', 'Islamabad'), []);
});

test('search can match part of address and returns empty when unmatched', () => {
  assert.deepEqual(filterHospitals(hospitals, 'Satellite Town').map((h) => h.id), ['h2']);
  assert.deepEqual(filterHospitals(hospitals, 'no hospital here'), []);
});
