import assert from 'node:assert/strict';
import test from 'node:test';
import { getRequestStatus, updateRequestStatusList } from './requestStatus.js';

test('old assignment requests without status are Open', () => {
  assert.equal(getRequestStatus({ id: 'old' }), 'open');
});

test('status update changes only selected request, preserving other records', () => {
  const original = [{ id: 'r1', status: 'open' }, { id: 'r2', status: 'open' }];
  const changed = updateRequestStatusList(original, 'r1', 'fulfilled');
  assert.deepEqual(changed, [{ id: 'r1', status: 'fulfilled' }, { id: 'r2', status: 'open' }]);
  assert.equal(original[0].status, 'open');
});
