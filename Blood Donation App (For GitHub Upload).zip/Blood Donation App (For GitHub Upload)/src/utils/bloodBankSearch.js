// Filter by search text and city. No live availability is implied.
export function filterBloodBanks(banks, query = '', city = 'All') {
  const lower = query.trim().toLowerCase();
  return banks.filter((bank) => {
    const correctCity = city === 'All' || bank.city === city;
    return correctCity && `${bank.name} ${bank.city} ${bank.address} ${bank.type}`.toLowerCase().includes(lower);
  });
}
