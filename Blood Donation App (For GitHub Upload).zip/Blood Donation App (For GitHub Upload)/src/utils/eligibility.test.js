import assert from 'node:assert/strict';
import test from 'node:test';
import { checkEligibility, checkReadiness, findCompatibleDonors } from './eligibility.js';

test('eligibility needs age 18+ and an active account', () => {
  assert.deepEqual(checkEligibility(21, 'active'), { registration: 'Eligible', canDonate: true });
  assert.deepEqual(checkEligibility(18, 'inactive'), { registration: 'Eligible', canDonate: false });
  assert.deepEqual(checkEligibility(17, 'active'), { registration: 'Not Eligible', canDonate: false });
});

test('eligibility handles text from inputs', () => {
  assert.equal(checkEligibility('21', 'active').canDonate, true);
  assert.equal(checkEligibility('', 'active').canDonate, false);
  assert.equal(checkEligibility('abc', 'active').canDonate, false);
});

test('readiness needs 70% and at least 5 activities', () => {
  assert.equal(checkReadiness(4, 5).completion, 80);
  assert.equal(checkReadiness(4, 5).ready, true);
  assert.equal(checkReadiness(3, 5).ready, false);
  assert.equal(checkReadiness(3, 4).ready, false);
  assert.equal(checkReadiness(0, 0).completion, 0);
});

test('compatible donors follow the blood group table and skip inactive or minors', () => {
  const donors = [
    { id: '1', group: 'O-', age: 30, status: 'active' },
    { id: '2', group: 'A+', age: 30, status: 'active' },
    { id: '3', group: 'O-', age: 30, status: 'inactive' },
    { id: '4', group: 'O-', age: 16, status: 'active' },
  ];
  const ids = (group) => findCompatibleDonors(donors, group).map((d) => d.id);
  assert.deepEqual(ids('O-'), ['1']);
  assert.deepEqual(ids('A+'), ['1', '2']);
  assert.deepEqual(ids('B+'), ['1']);
  assert.deepEqual(ids('AB+'), ['1', '2']);
  assert.deepEqual(ids('unknown'), []);
});


test('seeker can filter compatible donors by city (case-insensitive)', () => {
  const donors = [
    { id: '1', name: 'Ali', group: 'O-', age: 21, status: 'active', city: 'Islamabad' },
    { id: '2', name: 'Sara', group: 'O+', age: 24, status: 'active', city: 'Lahore' },
    { id: '3', name: 'Hina', group: 'O-', age: 24, status: 'inactive', city: 'Islamabad' },
  ];
  assert.deepEqual(findCompatibleDonors(donors, 'O+', ' ISLAM ').map((d) => d.id), ['1']);
  assert.deepEqual(findCompatibleDonors(donors, 'O+', '').map((d) => d.id), ['1', '2']);
});
