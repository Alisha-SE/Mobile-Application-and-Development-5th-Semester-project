// Only share requests after the user explicitly presses a share button.
// Do not invent donor availability or include private donor contact information.
export function buildRequestMessage(request) {
  const patient = (request.patient || 'Patient').trim();
  const group = (request.group || 'Not specified').trim();
  const units = String(request.units || 'Not specified').trim();
  const hospital = (request.hospital || 'Not specified').trim();
  const phone = (request.phone || 'Not specified').trim();
  return `BLOOD REQUEST\nPatient: ${patient}\nBlood Group: ${group}\nUnits: ${units}\nHospital: ${hospital}\nContact: ${phone}\nPlease confirm with the hospital before donating.`;
}
