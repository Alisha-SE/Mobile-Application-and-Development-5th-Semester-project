export const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];

// Red-cell compatibility: which donor groups each patient group can receive from.
const RECEIVES_FROM = {
  'O-': ['O-'],
  'O+': ['O-', 'O+'],
  'A-': ['O-', 'A-'],
  'A+': ['O-', 'O+', 'A-', 'A+'],
  'B-': ['O-', 'B-'],
  'B+': ['O-', 'O+', 'B-', 'B+'],
  'AB-': ['O-', 'A-', 'B-', 'AB-'],
  'AB+': BLOOD_GROUPS,
};

// Assignment 1, Question 1: age check plus account status.
export function checkEligibility(age, accountStatus) {
  const isAdult = Number(age) >= 18;
  return {
    registration: isAdult ? 'Eligible' : 'Not Eligible',
    canDonate: isAdult && accountStatus === 'active',
  };
}

// Assignment 1, Question 2: completion percentage plus activity count.
export function checkReadiness(doneCount, totalCount) {
  const completion = totalCount === 0 ? 0 : Math.round((doneCount / totalCount) * 100);
  return {
    completion,
    status: completion >= 70 ? 'Preparation Completed' : 'Preparation In Progress',
    ready: completion >= 70 && totalCount >= 5,
  };
}

export function isDonorAvailable(donor) {
  // Older Assignment 2 donor records have no availability property; default to available.
  return donor.available !== false;
}

// Existing three-argument usage keeps working. Extra filters are optional.
export function findCompatibleDonors(donors, patientGroup, citySearch = '', options = {}) {
  const accepted = RECEIVES_FROM[patientGroup] || [];
  const city = citySearch.trim().toLowerCase();
  const name = String(options.nameSearch || '').trim().toLowerCase();
  const availableOnly = options.availableOnly !== false;
  const filtered = donors.filter((donor) => {
    const eligible = checkEligibility(donor.age, donor.status).canDonate;
    const sameCity = (donor.city || '').toLowerCase().includes(city);
    const sameName = (donor.name || '').toLowerCase().includes(name);
    const matchesAvailability = !availableOnly || isDonorAvailable(donor);
    return accepted.includes(donor.group) && eligible && sameCity && sameName && matchesAvailability;
  });
  return options.sort === 'name' ? [...filtered].sort((a, b) => a.name.localeCompare(b.name)) : filtered;
}

