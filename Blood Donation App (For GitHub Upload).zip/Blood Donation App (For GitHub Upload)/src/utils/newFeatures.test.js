const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const load = (file) => {
  let s = fs.readFileSync(path.join(__dirname, file), 'utf8');
  s = s.replace(/export\s+(?=function|const)/g, '');
  return new Function(`${s}; return {findCompatibleDonors: typeof findCompatibleDonors === 'function' ? findCompatibleDonors : undefined, isDonorAvailable: typeof isDonorAvailable === 'function' ? isDonorAvailable : undefined, getMyRequests: typeof getMyRequests === 'function' ? getMyRequests : undefined, sortRequests: typeof sortRequests === 'function' ? sortRequests : undefined, updateRequestStatusList: typeof updateRequestStatusList === 'function' ? updateRequestStatusList : undefined}`)();
};
const eligibility = load('eligibility.js');
const request = load('requestStatus.js');
const d = [
  {id:'d1',name:'Ali',group:'O+',age:25,status:'active',city:'Islamabad'},
  {id:'a',name:'Ayesha',group:'O+',age:25,status:'active',city:'Rawalpindi',available:false},
  {id:'b',name:'Zara',group:'B+',age:25,status:'active',city:'Islamabad',available:true},
];
test('Availability defaults true for old records',()=>assert.equal(eligibility.isDonorAvailable(d[0]),true));
test('available-only excludes unavailable donors',()=>assert.deepEqual(eligibility.findCompatibleDonors(d,'O+').map(x=>x.name),['Ali']));
test('turning availability filter off shows eligible unavailable donors',()=>assert.equal(eligibility.findCompatibleDonors(d,'O+','',{availableOnly:false}).length,2));
test('city and name combined filters work',()=>assert.equal(eligibility.findCompatibleDonors(d,'O+','Rawal',{nameSearch:'aye',availableOnly:false})[0].name,'Ayesha'));
test('group matching is still respected',()=>assert.equal(eligibility.findCompatibleDonors(d,'O+','Islamabad').some(x=>x.group==='B+'),false));
const r = [{id:'r1',status:'open',urgent:true},{id:'2',origin:'local',status:'fulfilled'},{id:'3',origin:'local',status:'open',urgent:true}];
test('My Requests excludes sample requests',()=>assert.equal(request.getMyRequests(r).length,2));
test('urgent open requests appear first',()=>assert.equal(request.sortRequests(r)[0].urgent,true));
test('request status can be changed only for own records',()=>assert.equal(request.updateRequestStatusList(r,'r1','fulfilled',true)[0].status,'open'));
test('own record status changes',()=>assert.equal(request.updateRequestStatusList(r,'3','fulfilled',true)[2].status,'fulfilled'));
