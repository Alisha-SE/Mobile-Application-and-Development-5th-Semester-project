import { StyleSheet } from 'react-native';

export const colors = {
  primary: '#C8202F',
  primaryDark: '#B3121D',
  soft: '#FBD9DB',
  background: '#FDF1F2',
  card: '#FFFFFF',
  text: '#1F2933',
  muted: '#5F6B76',
  border: '#F0CDD0',
  white: '#FFFFFF',
};

export const fonts = {
  regular: 'Inter_400Regular',
  semibold: 'Inter_600SemiBold',
  bold: 'Inter_700Bold',
};

// Global styles shared across screens.
export const globalStyles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  content: { padding: 16, paddingBottom: 32 },
  card: { backgroundColor: colors.card, borderRadius: 16, padding: 16, marginBottom: 12 },
  title: { fontFamily: fonts.bold, fontSize: 18, color: colors.text, marginBottom: 8 },
  body: { fontFamily: fonts.regular, fontSize: 15, color: colors.text, marginBottom: 4 },
  muted: { fontFamily: fonts.regular, fontSize: 14, color: colors.muted },
});
