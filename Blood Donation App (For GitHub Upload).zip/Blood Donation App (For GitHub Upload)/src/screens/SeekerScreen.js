import { useContext, useEffect, useState } from 'react';
import { FlatList, StyleSheet, Switch, Text, TouchableOpacity, View } from 'react-native';
import GroupPicker from '../components/GroupPicker';
import Field from '../components/Field';
import { BloodContext } from '../context/BloodContext';
import { findCompatibleDonors, isDonorAvailable } from '../utils/eligibility';
import { fonts, colors, globalStyles } from '../styles';

export default function SeekerScreen({ navigation }) {
  const { donors } = useContext(BloodContext);
  const [group, setGroup] = useState('O+');
  const [citySearch, setCitySearch] = useState('');
  const [nameSearch, setNameSearch] = useState('');
  const [availableOnly, setAvailableOnly] = useState(true);
  const [sortByName, setSortByName] = useState(false);
  const matches = findCompatibleDonors(donors, group, citySearch, {
    nameSearch, availableOnly, sort: sortByName ? 'name' : 'recent',
  });

  useEffect(() => {
    navigation.setOptions({ title: `Seeker (${matches.length} matches)` });
  }, [navigation, matches.length]);

  function resetFilters() {
    setGroup('O+');
    setCitySearch('');
    setNameSearch('');
    setAvailableOnly(true);
    setSortByName(false);
  }

  return (
    <View style={globalStyles.screen}>
      <FlatList
        contentContainerStyle={globalStyles.content}
        data={matches}
        keyExtractor={(item) => item.id}
        keyboardShouldPersistTaps="handled"
        ListHeaderComponent={
          <View style={globalStyles.card}>
            <Text style={globalStyles.title}>Advanced Donor Search</Text>
            <GroupPicker label="Patient blood group" value={group} onChange={setGroup} />
            <Field label="City (optional)" value={citySearch} onChangeText={setCitySearch} placeholder="Islamabad, Rawalpindi..." />
            <Field label="Donor name (optional)" value={nameSearch} onChangeText={setNameSearch} placeholder="Search donor name" />
            <View style={styles.switchRow}>
              <Text style={styles.switchLabel}>Only available donors</Text>
              <Switch value={availableOnly} onValueChange={setAvailableOnly} trackColor={{ true: colors.primary }} accessibilityLabel="Only available donors" />
            </View>
            <View style={styles.switchRow}>
              <Text style={styles.switchLabel}>Sort names A to Z</Text>
              <Switch value={sortByName} onValueChange={setSortByName} trackColor={{ true: colors.primary }} accessibilityLabel="Sort names A to Z" />
            </View>
            <TouchableOpacity onPress={resetFilters} accessibilityRole="button" style={styles.reset}>
              <Text style={styles.resetText}>Reset filters</Text>
            </TouchableOpacity>
            <Text style={styles.count}>{matches.length} compatible donor(s) found</Text>
          
          </View>
        }
        ListEmptyComponent={<View style={globalStyles.card}><Text style={globalStyles.muted}>No donors match these filters. Try another city or turn off Available only.</Text></View>}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={globalStyles.card}
            accessibilityRole="button"
            onPress={() => navigation.navigate('DonorDetail', { donor: item })}
          >
            <View style={styles.nameRow}>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={styles.group}>{item.group}</Text>
            </View>
            <Text style={globalStyles.body}>City: {item.city}</Text>
            <Text style={isDonorAvailable(item) ? styles.available : styles.unavailable}>
              {isDonorAvailable(item) ? '● Available' : '● Unavailable'} (self-reported)
            </Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  nameRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  name: { fontFamily: fonts.semibold, fontSize: 16, color: colors.text, marginBottom: 4 },
  group: { fontFamily: fonts.bold, fontSize: 16, color: colors.primaryDark },
  switchRow: { flexDirection: 'row', minHeight: 44, alignItems: 'center', justifyContent: 'space-between' },
  switchLabel: { flex: 1, fontFamily: fonts.semibold, fontSize: 14, color: colors.text },
  reset: { alignSelf: 'flex-start', paddingVertical: 8 },
  resetText: { color: colors.primaryDark, fontFamily: fonts.semibold },
  count: { fontFamily: fonts.bold, color: colors.text, marginTop: 6, marginBottom: 8 },
  available: { color: '#267046', fontFamily: fonts.semibold, fontSize: 13 },
  unavailable: { color: colors.muted, fontFamily: fonts.semibold, fontSize: 13 },
});
