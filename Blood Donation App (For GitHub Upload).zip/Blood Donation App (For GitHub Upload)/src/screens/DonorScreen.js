import { useContext, useState } from 'react';
import { ActivityIndicator, FlatList, StyleSheet, Text, View } from 'react-native';
import Field from '../components/Field';
import GroupPicker from '../components/GroupPicker';
import PrimaryButton from '../components/PrimaryButton';
import { BloodContext } from '../context/BloodContext';
import { useForm } from '../hooks/useForm';
import { checkEligibility, isDonorAvailable } from '../utils/eligibility';
import { colors, fonts, globalStyles } from '../styles';

function validateDonor(values) {
  const errors = {};
  if (!values.name.trim()) errors.name = 'Enter the donor name';
  if (!/^[0-9]+$/.test(values.age)) {
    errors.age = 'Enter a valid age';
  } else if (checkEligibility(values.age, 'active').registration === 'Not Eligible') {
    errors.age = 'Donors must be 18 or older';
  }
  if (!values.group) errors.group = 'Select a blood group';
  if (!/^[0-9]{10,13}$/.test(values.phone)) errors.phone = 'Enter 10 to 13 digits';
  if (!values.city.trim()) errors.city = 'Enter the city';
  return errors;
}

export default function DonorScreen() {
  const { donors, addDonor } = useContext(BloodContext);
  const { values, errors, setField, handleSubmit } = useForm(
    { name: '', age: '', group: '', phone: '', city: '' },
    validateDonor
  );
  const [message, setMessage] = useState('');
  const [saving, setSaving] = useState(false);

  const onSubmit = async () => {
    setMessage(''); setSaving(true);
    try {
      await handleSubmit(async (formValues) => {
        await addDonor({
          ...formValues, name: formValues.name.trim(),
          city: formValues.city.trim(), age: Number(formValues.age),
        });
        setMessage(`${formValues.name.trim()} registered successfully in Firestore.`);
      });
    } catch (error) { setMessage(error.message || 'Could not register donor.'); }
    finally { setSaving(false); }
  };

  return (
    <View style={globalStyles.screen}>
      <FlatList
        contentContainerStyle={globalStyles.content}
        keyboardShouldPersistTaps="handled"
        data={donors}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={
          <View>
            <View style={globalStyles.card}>
              <Text style={globalStyles.title}>Register as a Donor</Text>
              <Field label="Name" value={values.name} onChangeText={(text) => setField('name', text)} error={errors.name} />
              <Field
                label="Age"
                value={values.age}
                onChangeText={(text) => setField('age', text)}
                error={errors.age}
                keyboardType="number-pad"
              />
              <GroupPicker label="Blood group" value={values.group} onChange={(group) => setField('group', group)} error={errors.group} />
              <Field
                label="Phone"
                value={values.phone}
                onChangeText={(text) => setField('phone', text)}
                error={errors.phone}
                keyboardType="phone-pad"
              />
              <Field label="City" value={values.city} onChangeText={(text) => setField('city', text)} error={errors.city} />
              {saving ? <ActivityIndicator color={colors.primary}/> : <PrimaryButton title="Register" onPress={onSubmit} />}
             
              {message ? <Text style={styles.success}>{message}</Text> : null}
            </View>
            <Text style={globalStyles.title}>Registered Donors</Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={globalStyles.card}>
            <Text style={styles.name}>{item.name}</Text>
            <Text style={globalStyles.body}>Blood group: {item.group}</Text>
            <Text style={globalStyles.body}>City: {item.city}</Text>
            <Text style={styles.availability}>Availability: {isDonorAvailable(item) ? 'Available' : 'Unavailable'}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  note: { fontFamily: fonts.regular, fontSize: 12, color: colors.muted, marginTop: 10, marginBottom: 4 },
  success: { fontFamily: fonts.semibold, fontSize: 14, color: colors.primaryDark, marginTop: 12 },
  availability: { color: colors.primaryDark, fontSize: 13, fontFamily: fonts.semibold },
  name: { fontFamily: fonts.semibold, fontSize: 16, color: colors.text, marginBottom: 4 },
});
