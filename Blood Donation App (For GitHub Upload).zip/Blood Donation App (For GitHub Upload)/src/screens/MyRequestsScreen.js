import { useContext, useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { BloodContext } from '../context/BloodContext';
import PrimaryButton from '../components/PrimaryButton';
import { getRequestStatus } from '../utils/requestStatus';
import { colors, fonts, globalStyles } from '../styles';

export default function MyRequestsScreen({ navigation }) {
  const { user, requests, changeRequestStatus } = useContext(BloodContext);
  const [filter, setFilter] = useState('All');
  const mine = requests.filter((request) => request.ownerUid === user?.uid);
  const listed = mine.filter((request) => filter === 'All' || getRequestStatus(request) === filter.toLowerCase());
  const open = mine.filter((request) => getRequestStatus(request) === 'open').length;
  const complete = mine.length - open;
  async function changeStatus(id, status) {
    try { await changeRequestStatus(id, status); }
    catch (error) { Alert.alert('Update failed', error.message); }
  }

  return (
    <ScrollView style={globalStyles.screen} contentContainerStyle={globalStyles.content}>
      <View style={globalStyles.card}>
        <Text style={globalStyles.title}>My Requests & History</Text>
        <Text style={globalStyles.muted}>View and manage blood requests created with your account.</Text>
        <View style={styles.summary}>
          <View><Text style={styles.number}>{open}</Text><Text style={globalStyles.muted}>Open</Text></View>
          <View><Text style={styles.number}>{complete}</Text><Text style={globalStyles.muted}>Fulfilled</Text></View>
          <View><Text style={styles.number}>{mine.length}</Text><Text style={globalStyles.muted}>Total</Text></View>
        </View>
      </View>
      <View style={styles.filters}>
        {['All', 'Open', 'Fulfilled'].map((name) => (
          <TouchableOpacity key={name} onPress={() => setFilter(name)} accessibilityRole="button" style={[styles.chip, filter === name && styles.activeChip]}>
            <Text style={[styles.chipText, filter === name && styles.activeText]}>{name}</Text>
          </TouchableOpacity>
        ))}
      </View>
      {listed.length === 0 ? (
        <View style={globalStyles.card}>
          <Text style={styles.name}>No requests here</Text>
          <Text style={globalStyles.muted}>Post your first request to see it in this section.</Text>
          <PrimaryButton title="Post New Request" onPress={() => navigation.navigate('Request')} />
        </View>
      ) : listed.map((request) => (
        <View key={request.id} style={globalStyles.card}>
          <View style={styles.row}>
            <Text style={styles.name}>{request.patient}</Text>
            {request.urgent && getRequestStatus(request) === 'open' ? <Text style={styles.urgent}>URGENT</Text> : null}
            <Text style={styles.group}>{request.group}</Text>
          </View>
          <Text style={globalStyles.body}>{request.units} unit(s) · {request.hospital}</Text>
          <Text style={globalStyles.muted}>Contact: {request.phone}</Text>
          <Text style={styles.status}>Status: {getRequestStatus(request) === 'open' ? 'Open' : 'Fulfilled'}</Text>
          <PrimaryButton
            title={getRequestStatus(request) === 'open' ? 'Mark Fulfilled' : 'Reopen Request'}
            onPress={() => changeStatus(request.id, getRequestStatus(request) === 'open' ? 'fulfilled' : 'open')}
          />
        </View>
      ))}
      <Text style={globalStyles.muted}>Your request history is stored in Firestore and only you can update its status.</Text>
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  summary: { flexDirection: 'row', justifyContent: 'space-around', marginTop: 18 },
  number: { color: colors.primaryDark, fontFamily: fonts.bold, fontSize: 24, textAlign: 'center' },
  filters: { flexDirection: 'row', gap: 8, marginBottom: 12 },
  chip: { backgroundColor: colors.white, borderColor: colors.border, borderWidth: 1, borderRadius: 12, paddingHorizontal: 18, paddingVertical: 11 },
  activeChip: { backgroundColor: colors.primary },
  chipText: { fontFamily: fonts.semibold, color: colors.text },
  activeText: { color: colors.white },
  row: { flexDirection: 'row', gap: 7, alignItems: 'center', marginBottom: 8 },
  name: { fontFamily: fonts.bold, color: colors.text, fontSize: 16, flex: 1 },
  group: { color: colors.primaryDark, fontFamily: fonts.bold },
  urgent: { fontFamily: fonts.bold, color: colors.white, backgroundColor: colors.primary, fontSize: 10, paddingVertical: 5, paddingHorizontal: 7, borderRadius: 6 },
  status: { fontFamily: fonts.semibold, color: colors.primaryDark, marginVertical: 10 },
});
