import { useContext, useState } from 'react';
import { ActivityIndicator, FlatList, StyleSheet, Switch, Text, TouchableOpacity, View } from 'react-native';
import Field from '../components/Field';
import GroupPicker from '../components/GroupPicker';
import PrimaryButton from '../components/PrimaryButton';
import { BloodContext } from '../context/BloodContext';
import { useForm } from '../hooks/useForm';
import { colors, fonts, globalStyles } from '../styles';
import { getRequestStatus, sortRequests } from '../utils/requestStatus';

function validateRequest(values) {
  const errors = {};
  if (!values.patient.trim()) errors.patient = 'Enter the patient name';
  if (!values.group) errors.group = 'Select a blood group';
  if (!/^[0-9]+$/.test(values.units) || Number(values.units) < 1 || Number(values.units) > 10) {
    errors.units = 'Enter 1 to 10 units';
  }
  if (!values.hospital.trim()) errors.hospital = 'Enter the hospital';
  if (!/^[0-9]{10,13}$/.test(values.phone)) errors.phone = 'Enter 10 to 13 digits';
  return errors;
}

export default function RequestScreen({ route }) {
  const { requests, addRequest } = useContext(BloodContext);
  const { values, errors, setField, handleSubmit } = useForm(
    { patient: '', group: '', units: '', hospital: '', phone: '' },
    validateRequest
  );
  const [message, setMessage] = useState('');
  const [showAll, setShowAll] = useState(false);
  const [urgent, setUrgent] = useState(route?.params?.startUrgent === true);
  const [allowShare, setAllowShare] = useState(false);
  const [saving, setSaving] = useState(false);
  const visibleRequests = sortRequests(showAll ? requests : requests.filter((request) => getRequestStatus(request) === 'open'));

  const onSubmit = async () => {
    setMessage(''); setSaving(true);
    try {
      await handleSubmit(async (formValues) => {
        await addRequest({ ...formValues,
          patient: formValues.patient.trim(),
          hospital: formValues.hospital.trim(),
          urgent, allowShare,
        });
        setUrgent(false); setAllowShare(false);
        setMessage(`Request for ${formValues.patient.trim()} saved in Firestore.`);
      });
    } catch (error) { setMessage(error.message || 'Could not save request.'); }
    finally { setSaving(false); }
  };

  return (
    <View style={globalStyles.screen}>
      <FlatList
        contentContainerStyle={globalStyles.content}
        keyboardShouldPersistTaps="handled"
        data={visibleRequests}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={
          <View>
            <View style={globalStyles.card}>
              <Text style={globalStyles.title}>Post a Blood Request</Text>
              <Field label="Patient name" value={values.patient} onChangeText={(text) => setField('patient', text)} error={errors.patient} />
              <GroupPicker label="Blood group" value={values.group} onChange={(group) => setField('group', group)} error={errors.group} />
              <Field
                label="Units needed"
                value={values.units}
                onChangeText={(text) => setField('units', text)}
                error={errors.units}
                keyboardType="number-pad"
              />
              <Field label="Hospital" value={values.hospital} onChangeText={(text) => setField('hospital', text)} error={errors.hospital} />
              <Field
                label="Contact phone"
                value={values.phone}
                onChangeText={(text) => setField('phone', text)}
                error={errors.phone}
                keyboardType="phone-pad"
              />
              <View style={styles.switchRow}>
                <View style={styles.switchInfo}>
                  <Text style={styles.switchLabel}>Emergency request</Text>
                  <Text style={globalStyles.muted}>Mark urgent requests so they appear first.</Text>
                </View>
                <Switch value={urgent} onValueChange={setUrgent} trackColor={{ true: colors.primary }} accessibilityLabel="Emergency request" />
              </View>
              {urgent ? <Text style={styles.emergencyHint}>URGENT • Please confirm details with the hospital.</Text> : null}
              <View style={styles.switchRow}>
                <View style={styles.switchInfo}>
                  <Text style={styles.switchLabel}>Allow sharing this request</Text>
                  <Text style={globalStyles.muted}>Only enable if the patient agrees to share the contact phone number.</Text>
                </View>
                <Switch value={allowShare} onValueChange={setAllowShare} trackColor={{true: colors.primary}} />
              </View>
              {saving ? <ActivityIndicator color={colors.primary}/> : <PrimaryButton title={urgent ? 'Post Urgent Request' : 'Post Request'} onPress={onSubmit} />}
              {message ? <Text style={styles.success}>{message}</Text> : null}
            </View>
            <Text style={globalStyles.title}>Blood Requests</Text>
            <View style={styles.filterRow}>
              <TouchableOpacity style={[styles.filterButton, !showAll && styles.activeFilter]} onPress={() => setShowAll(false)}>
                <Text style={[styles.filterText, !showAll && styles.activeFilterText]}>Open</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.filterButton, showAll && styles.activeFilter]} onPress={() => setShowAll(true)}>
                <Text style={[styles.filterText, showAll && styles.activeFilterText]}>All</Text>
              </TouchableOpacity>
            </View>
          </View>
        }
        ListEmptyComponent={<Text style={globalStyles.muted}>No requests found in this filter.</Text>}
        renderItem={({ item }) => (
          <View style={globalStyles.card}>
            <View style={styles.headingRow}><Text style={styles.name}>{item.patient}</Text>{item.urgent && getRequestStatus(item) === 'open' ? <Text style={styles.urgent}>URGENT</Text> : null}</View>
            <Text style={globalStyles.body}>Blood group: {item.group}</Text>
            <Text style={globalStyles.body}>Units: {item.units}</Text>
            <Text style={globalStyles.body}>Hospital: {item.hospital}</Text>
            <Text style={globalStyles.body}>Phone: {item.phone}</Text>
            <Text style={styles.status}>Status: {getRequestStatus(item) === 'open' ? 'Open' : 'Fulfilled'}</Text>
            <Text style={styles.note}>To manage a request you created, open My Requests & History.</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  success: { fontFamily: fonts.semibold, fontSize: 14, color: colors.primaryDark, marginTop: 12 },
  name: { fontFamily: fonts.semibold, fontSize: 16, color: colors.text, marginBottom: 4 },
  status: { fontFamily: fonts.semibold, fontSize: 14, color: colors.primaryDark, marginVertical: 8 },
  switchRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginVertical: 12, gap: 10 },
  switchInfo: { flex: 1 },
  switchLabel: { fontFamily: fonts.semibold, color: colors.text, fontSize: 15 },
  emergencyHint: { color: colors.primaryDark, fontFamily: fonts.semibold, marginBottom: 10 },
  headingRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  urgent: { backgroundColor: colors.primary, color: colors.white, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 5, fontFamily: fonts.bold, fontSize: 11 },
  note: { fontFamily: fonts.regular, fontSize: 12, color: colors.muted, marginTop: 8 },
  filterRow: { flexDirection: 'row', gap: 10, marginBottom: 12 },
  filterButton: { borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingVertical: 10, paddingHorizontal: 24, backgroundColor: colors.card },
  activeFilter: { backgroundColor: colors.primary, borderColor: colors.primary },
  filterText: { fontFamily: fonts.semibold, color: colors.text },
  activeFilterText: { color: colors.white },
});
