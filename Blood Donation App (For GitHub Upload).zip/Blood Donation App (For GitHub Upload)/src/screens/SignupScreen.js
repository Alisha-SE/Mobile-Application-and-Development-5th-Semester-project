import { useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { registerAccount } from '../services/firebaseService';
import { colors, fonts, globalStyles } from '../styles';
export default function SignupScreen({ navigation }) {
  const [name,setName]=useState(''); const [email,setEmail]=useState('');
  const [password,setPassword]=useState(''); const [role,setRole]=useState('Donor');
  const [error,setError]=useState(''); const [busy,setBusy]=useState(false);
  async function signup() {
    if (!name.trim()) return setError('Enter your name.');
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) return setError('Enter a valid email.');
    if (password.length<6) return setError('Password needs at least 6 characters.');
    setBusy(true);setError('');
    try { await registerAccount({name,email,password,role}); }
    catch(e) { setError(e.code==='auth/email-already-in-use'?'Email already registered.':e.message); }
    finally { setBusy(false); }
  }
  return <ScrollView style={globalStyles.screen} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
    <MaterialCommunityIcons name="account-plus" size={62} color={colors.primary}/>
    <Text style={styles.title}>Create your account</Text>
    <View style={globalStyles.card}>
      <Text style={styles.label}>Full name</Text><TextInput style={styles.input} value={name} onChangeText={setName} placeholder="Your name"/>
      <Text style={styles.label}>Email</Text><TextInput style={styles.input} value={email} onChangeText={setEmail} placeholder="Email" autoCapitalize="none" keyboardType="email-address"/>
      <Text style={styles.label}>Password</Text><TextInput style={styles.input} value={password} onChangeText={setPassword} placeholder="At least 6 characters" secureTextEntry/>
      <Text style={styles.label}>Role</Text><View style={styles.row}>{['Donor','Seeker'].map(v=><TouchableOpacity key={v} style={[styles.role,v===role&&styles.selected]} onPress={()=>setRole(v)}><Text style={{color:v===role?colors.white:colors.text}}>{v}</Text></TouchableOpacity>)}</View>
      {!!error&&<Text style={styles.error}>{error}</Text>}
      {busy?<ActivityIndicator color={colors.primary}/>:<TouchableOpacity style={styles.button} onPress={signup}><Text style={styles.white}>Create Account</Text></TouchableOpacity>}
      <TouchableOpacity onPress={()=>navigation.navigate('Login')}><Text style={styles.link}>Already registered? Log in</Text></TouchableOpacity>
    </View>
  </ScrollView>;
}
const styles=StyleSheet.create({
  content:{padding:20,alignItems:'center',paddingTop:22},title:{fontSize:24,color:colors.primaryDark,fontFamily:fonts.bold,marginBottom:15},
  label:{color:colors.text,fontFamily:fonts.semibold,marginBottom:6},
  input:{borderWidth:1,borderColor:colors.border,borderRadius:12,padding:12,marginBottom:14,color:colors.text,backgroundColor:colors.white},
  row:{flexDirection:'row',gap:10,marginBottom:16},role:{flex:1,padding:13,borderRadius:11,alignItems:'center',borderWidth:1,borderColor:colors.border},selected:{backgroundColor:colors.primary,borderColor:colors.primary},
  button:{backgroundColor:colors.primary,borderRadius:11,padding:14,alignItems:'center'},white:{color:colors.white,fontFamily:fonts.bold},
  link:{color:colors.primaryDark,fontFamily:fonts.semibold,marginTop:18,textAlign:'center'},error:{color:colors.primaryDark,marginBottom:12}
});
