import { Linking, ScrollView, StyleSheet, Text, View } from 'react-native';
import PrimaryButton from '../components/PrimaryButton';
import { isDonorAvailable } from '../utils/eligibility';
import { colors, fonts, globalStyles } from '../styles';

export default function DonorDetailScreen({ route }) {
  const { donor } = route.params;

  return (
    <View style={globalStyles.screen}>
      <ScrollView contentContainerStyle={globalStyles.content}>
        <View style={globalStyles.card}>
          <Text style={styles.name}>{donor.name}</Text>
          <Text style={globalStyles.body}>Blood group: {donor.group}</Text>
          <Text style={globalStyles.body}>Age: {donor.age}</Text>
          <Text style={globalStyles.body}>City: {donor.city}</Text>
          <Text style={globalStyles.body}>Availability: {isDonorAvailable(donor) ? 'Available (self-reported)' : 'Unavailable'}</Text>
          <Text style={globalStyles.body}>Phone: {donor.phone}</Text>
        </View>
        {!isDonorAvailable(donor) ? (
          <Text style={globalStyles.muted}>This donor is currently unavailable for contact.</Text>
        ) : (
          <PrimaryButton title="Call Donor" onPress={() => Linking.openURL(`tel:${donor.phone}`)} />
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  name: { fontFamily: fonts.bold, fontSize: 22, color: colors.text, marginBottom: 8 },
});
