import { useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, TextInput, TouchableOpacity, View, ScrollView } from 'react-native';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { loginAccount } from '../services/firebaseService';
import { colors, fonts, globalStyles } from '../styles';
export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  async function handleLogin() {
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) return setError('Enter a valid email.');
    if (!password) return setError('Enter your password.');
    setError(''); setBusy(true);
    try { await loginAccount(email, password); }
    catch (e) { setError(e.code === 'auth/invalid-credential' ? 'Incorrect email or password.' : e.message); }
    finally { setBusy(false); }
  }
  return <ScrollView style={globalStyles.screen} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
    <MaterialCommunityIcons name="heart-circle" size={70} color={colors.primary}/>
    <Text style={styles.heading}>Welcome back</Text>
    <Text style={globalStyles.muted}>Sign in to find donors and manage blood requests.</Text>
    <View style={globalStyles.card}>
      <Text style={styles.label}>Email</Text>
      <TextInput style={styles.input} keyboardType="email-address" autoCapitalize="none" value={email} onChangeText={setEmail} placeholder="Email"/>
      <Text style={styles.label}>Password</Text>
      <TextInput style={styles.input} secureTextEntry value={password} onChangeText={setPassword} placeholder="Password"/>
      {!!error && <Text style={styles.error}>{error}</Text>}
      {busy ? <ActivityIndicator color={colors.primary}/> : <TouchableOpacity style={styles.button} onPress={handleLogin}><Text style={styles.white}>Log In</Text></TouchableOpacity>}
      <TouchableOpacity onPress={() => navigation.navigate('Signup')}><Text style={styles.link}>New user? Create account</Text></TouchableOpacity>
    </View>
  </ScrollView>;
}
const styles=StyleSheet.create({
  content:{padding:20,alignItems:'center',paddingTop:45},
  heading:{fontSize:25,color:colors.primaryDark,fontFamily:fonts.bold,marginBottom:6},
  label:{color:colors.text,fontFamily:fonts.semibold,marginBottom:6},
  input:{borderWidth:1,borderColor:colors.border,borderRadius:12,padding:13,marginBottom:15,color:colors.text,backgroundColor:colors.white},
  button:{backgroundColor:colors.primary,borderRadius:11,alignItems:'center',padding:14},
  white:{color:colors.white,fontFamily:fonts.bold},
  link:{color:colors.primaryDark,fontFamily:fonts.semibold,marginTop:18,textAlign:'center'},
  error:{color:colors.primaryDark,marginBottom:12},
});
