import { useContext } from 'react';
import { Alert, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import { BloodContext } from '../context/BloodContext';
import { isDonorAvailable } from '../utils/eligibility';
import { colors, fonts, globalStyles } from '../styles';

export default function AvailabilityScreen() {
  const { user, donors, changeDonorAvailability } = useContext(BloodContext);
  const myDonors = donors.filter((donor) => donor.ownerUid === user?.uid);
  async function toggle(id, available) {
    try { await changeDonorAvailability(id, available); }
    catch (error) { Alert.alert('Update failed', error.message); }
  }

  return (
    <ScrollView style={globalStyles.screen} contentContainerStyle={globalStyles.content}>
      <View style={globalStyles.card}>
        <Text style={globalStyles.title}>My Donor Availability</Text>
        <Text style={globalStyles.muted}>Turn your availability on or off for the donor records registered under your account.</Text>
      </View>
      {myDonors.length === 0 ? (
        <View style={globalStyles.card}>
          <Text style={styles.name}>No donor registration yet</Text>
          <Text style={globalStyles.muted}>Register on the Donor screen first. The availability toggle appears after you register.</Text>
        </View>
      ) : myDonors.map((donor) => (
        <View style={globalStyles.card} key={donor.id}>
          <View style={styles.row}>
            <View style={styles.details}>
              <Text style={styles.name}>{donor.name}</Text>
              <Text style={globalStyles.muted}>{donor.group} · {donor.city}</Text>
              <Text style={styles.status}>{isDonorAvailable(donor) ? 'Available for contact' : 'Not available'}</Text>
            </View>
            <Switch
              value={isDonorAvailable(donor)}
              onValueChange={(value) => toggle(donor.id, value)}
              trackColor={{ true: colors.primary }}
              accessibilityLabel={`Availability for ${donor.name}`}
            />
          </View>
        </View>
      ))}
  
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  details: { flex: 1 },
  name: { fontFamily: fonts.bold, color: colors.text, fontSize: 16, marginBottom: 4 },
  status: { color: colors.primaryDark, fontFamily: fonts.semibold, marginTop: 7, fontSize: 13 },
});
