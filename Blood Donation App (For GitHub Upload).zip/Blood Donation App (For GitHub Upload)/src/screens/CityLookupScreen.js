import { useState } from 'react';
import { ActivityIndicator, FlatList, Linking, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { searchPakistaniCities } from '../services/cityApi';
import { colors, fonts, globalStyles } from '../styles';

export default function CityLookupScreen() {
  const [search, setSearch] = useState('Islamabad');
  const [cities, setCities] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [searched, setSearched] = useState(false);

  async function lookup() {
    setError('');
    setSearched(true);
    setLoading(true);
    try {
      const results = await searchPakistaniCities(search);
      setCities(results);
    } catch (e) {
      setCities([]);
      setError(e.message || 'Please check your internet connection.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <View style={globalStyles.screen}>
      <FlatList
        contentContainerStyle={globalStyles.content}
        data={cities}
        keyExtractor={(item) => String(item.id)}
        keyboardShouldPersistTaps="handled"
        ListHeaderComponent={
          <View style={globalStyles.card}>
            <Text style={globalStyles.title}>City Lookup (Live API)</Text>
            <Text style={globalStyles.muted}>Search a Pakistani city using a real GET API. Internet is required.</Text>
            <TextInput style={styles.input} value={search} onChangeText={setSearch} placeholder="Enter city name" autoCapitalize="words" accessibilityLabel="City name" />
            <TouchableOpacity onPress={lookup} style={styles.button} accessibilityRole="button">
              <Text style={styles.buttonText}>Search with Fetch API</Text>
            </TouchableOpacity>
            {loading ? <ActivityIndicator size="large" color={colors.primary} style={{ marginTop: 15 }} /> : null}
            {error ? <Text style={styles.error}>{error}</Text> : null}
            {!loading && searched && !error ? <Text style={styles.info}>{cities.length} result(s)</Text> : null}
          </View>
        }
        ListEmptyComponent={!loading && searched && !error ? <Text style={globalStyles.muted}>No city matched. Try Islamabad or Rawalpindi.</Text> : null}
        renderItem={({ item }) => (
          <View style={globalStyles.card}>
            <Text style={styles.city}>{item.name}</Text>
            <Text style={globalStyles.body}>{item.region}, {item.country}</Text>
            <TouchableOpacity onPress={() => Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${item.latitude},${item.longitude}`)}>
              <Text style={styles.link}>View Location in Maps</Text>
            </TouchableOpacity>
          </View>
        )}
        ListFooterComponent={<Text style={globalStyles.muted}>Location information: Open-Meteo Geocoding API. This lookup does not provide blood availability.</Text>}
      />
    </View>
  );
}
const styles = StyleSheet.create({
  input: { borderWidth: 1, borderColor: colors.border, borderRadius: 12, marginVertical: 14, padding: 13, backgroundColor: colors.white, color: colors.text, fontFamily: fonts.regular },
  button: { backgroundColor: colors.primary, padding: 14, borderRadius: 12, alignItems: 'center' },
  buttonText: { fontFamily: fonts.semibold, color: colors.white },
  error: { color: colors.primaryDark, marginTop: 12 },
  info: { fontFamily: fonts.semibold, marginTop: 12, color: colors.text },
  city: { fontFamily: fonts.bold, fontSize: 18, color: colors.primaryDark },
  link: { fontFamily: fonts.semibold, marginTop: 12, color: colors.primaryDark },
});
