import { StyleSheet, Text, View } from 'react-native';
import { colors, fonts } from '../styles';
export default function SetupRequiredScreen() {
  return <View style={styles.center}>
    <Text style={styles.title}>Firebase Setup Required</Text>
    <Text style={styles.text}>Create a Firebase project and copy its web app configuration into the .env file. Restart Expo after editing .env.</Text>
    <Text style={styles.text}>Open FIREBASE_SETUP_ROMAN_URDU.md for exact instructions.</Text>
  </View>;
}
const styles=StyleSheet.create({center:{flex:1,alignItems:'center',justifyContent:'center',padding:24,backgroundColor:colors.soft},title:{fontFamily:fonts.bold,fontSize:22,color:colors.primaryDark,marginBottom:14},text:{fontFamily:fonts.regular,fontSize:15,color:colors.text,textAlign:'center',marginBottom:12}});
