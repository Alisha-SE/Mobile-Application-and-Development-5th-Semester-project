import { useEffect, useState } from 'react';
import {
  Alert,
  FlatList,
  Linking,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { HOSPITALS } from '../data/hospitals';
import { filterHospitals } from '../utils/hospitalSearch';
import { colors, fonts, globalStyles } from '../styles';

const CITIES = ['All', 'Islamabad', 'Rawalpindi'];

// Opens the phone dialer or Google Maps outside the application.
async function openExternalLink(url) {
  try {
    await Linking.openURL(url);
  } catch (error) {
    Alert.alert('Unable to open', 'Please try again or check this device.');
  }
}

export default function HospitalScreen({ navigation }) {
  const [searchText, setSearchText] = useState('');
  const [city, setCity] = useState('All');

  // The list changes automatically whenever the user types or chooses a city.
  const shownHospitals = filterHospitals(HOSPITALS, searchText, city);

  // Demonstrates useEffect: update the screen title when the match count changes.
  useEffect(() => {
    navigation.setOptions({ title: `Hospitals (${shownHospitals.length})` });
  }, [navigation, shownHospitals.length]);

  function openMap(hospital) {
    const location = encodeURIComponent(`${hospital.name}, ${hospital.address}`);
    openExternalLink(`https://www.google.com/maps/search/?api=1&query=${location}`);
  }

  function renderHospital({ item }) {
    return (
      <View style={globalStyles.card}>
        <View style={styles.nameRow}>
          <MaterialCommunityIcons name="hospital-building" size={30} color={colors.primary} />
          <View style={styles.nameContainer}>
            <Text style={styles.hospitalName}>{item.name}</Text>
            <Text style={styles.category}>{item.category} · {item.city}</Text>
          </View>
        </View>
        <Text style={styles.address}>{item.address}</Text>
        <Text style={styles.phone}>Phone: {item.phone || 'Not verified'}</Text>
        <View style={styles.actionRow}>
          {item.phone ? (
            <TouchableOpacity
              accessibilityRole="button"
              accessibilityLabel={`Call ${item.name}`}
              style={[styles.actionButton, styles.callButton]}
              onPress={() => openExternalLink(`tel:${item.phone}`)}
            >
              <MaterialCommunityIcons name="phone" size={18} color={colors.white} />
              <Text style={styles.callText}>Call</Text>
            </TouchableOpacity>
          ) : (
            <View style={[styles.actionButton, styles.disabledCall]}>
              <MaterialCommunityIcons name="phone-off" size={18} color={colors.muted} />
              <Text style={styles.disabledText}>No number</Text>
            </View>
          )}
          <TouchableOpacity
            accessibilityRole="button"
            accessibilityLabel={`View ${item.name} on Google Maps`}
            style={[styles.actionButton, styles.mapButton]}
            onPress={() => openMap(item)}
          >
            <MaterialCommunityIcons name="map-marker" size={18} color={colors.primaryDark} />
            <Text style={styles.mapText}>Location</Text>
          </TouchableOpacity>
          <TouchableOpacity
            accessibilityRole="button"
            accessibilityLabel={`View source for ${item.name}`}
            style={styles.sourceButton}
            onPress={() => openExternalLink(item.sourceUrl)}
          >
            <MaterialCommunityIcons name="open-in-new" size={20} color={colors.primaryDark} />
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={globalStyles.screen}>
      <FlatList
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={globalStyles.content}
        data={shownHospitals}
        keyExtractor={(item) => item.id}
        renderItem={renderHospital}
        ListHeaderComponent={
          <View>
            <Text style={styles.heading}>Find a Hospital</Text>
            <Text style={styles.intro}>Search hospitals in Islamabad and Rawalpindi.</Text>
            <View style={styles.searchBox}>
              <MaterialCommunityIcons name="magnify" size={23} color={colors.muted} />
              <TextInput
                style={styles.searchInput}
                placeholder="Search hospital or area"
                placeholderTextColor={colors.muted}
                accessibilityLabel="Search hospitals"
                value={searchText}
                onChangeText={setSearchText}
                autoCapitalize="none"
              />
              {searchText ? (
                <TouchableOpacity accessibilityLabel="Clear search" onPress={() => setSearchText('')}>
                  <MaterialCommunityIcons name="close-circle" size={20} color={colors.muted} />
                </TouchableOpacity>
              ) : null}
            </View>
            <View style={styles.cityRow}>
              {CITIES.map((option) => (
                <TouchableOpacity
                  key={option}
                  accessibilityRole="button"
                  style={[styles.cityButton, city === option && styles.cityButtonSelected]}
                  onPress={() => setCity(option)}
                >
                  <Text style={[styles.cityText, city === option && styles.cityTextSelected]}>{option}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <Text style={styles.resultCount}>{shownHospitals.length} hospital(s) found</Text>
          </View>
        }
        ListEmptyComponent={
          <View style={styles.emptyBox}>
            <MaterialCommunityIcons name="hospital-marker" size={40} color={colors.primary} />
            <Text style={styles.emptyTitle}>No hospitals found</Text>
            <Text style={globalStyles.muted}>Try another hospital name or city.</Text>
          </View>
        }
        ListFooterComponent={
          <Text style={styles.disclaimer}>
            Directory information only. Call the hospital to ask about blood bank services or blood availability before visiting. Contacts may change.
          </Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  heading: { fontFamily: fonts.bold, fontSize: 23, color: colors.primaryDark, marginBottom: 6 },
  intro: { fontFamily: fonts.regular, fontSize: 14, color: colors.muted, marginBottom: 16 },
  searchBox: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 12, backgroundColor: colors.card, borderRadius: 12, borderWidth: 1, borderColor: colors.border, minHeight: 48 },
  searchInput: { flex: 1, fontFamily: fonts.regular, fontSize: 15, color: colors.text, paddingVertical: 10 },
  cityRow: { flexDirection: 'row', gap: 8, marginVertical: 12 },
  cityButton: { paddingVertical: 10, paddingHorizontal: 11, borderRadius: 10, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.card, minHeight: 42, justifyContent: 'center' },
  cityButtonSelected: { backgroundColor: colors.primary, borderColor: colors.primary },
  cityText: { fontFamily: fonts.semibold, fontSize: 13, color: colors.text },
  cityTextSelected: { color: colors.white },
  resultCount: { fontFamily: fonts.semibold, fontSize: 14, color: colors.muted, marginBottom: 10 },
  nameRow: { flexDirection: 'row', gap: 10, alignItems: 'flex-start', marginBottom: 10 },
  nameContainer: { flex: 1 },
  hospitalName: { fontFamily: fonts.bold, fontSize: 16, color: colors.text, marginBottom: 4 },
  category: { fontFamily: fonts.regular, fontSize: 12, color: colors.muted },
  address: { fontFamily: fonts.regular, fontSize: 14, color: colors.text, marginBottom: 6 },
  phone: { fontFamily: fonts.regular, fontSize: 14, color: colors.muted, marginBottom: 12 },
  actionRow: { flexDirection: 'row', gap: 8, alignItems: 'center' },
  actionButton: { flex: 1, minHeight: 44, flexDirection: 'row', gap: 5, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  callButton: { backgroundColor: colors.primary },
  callText: { fontFamily: fonts.semibold, fontSize: 14, color: colors.white },
  disabledCall: { backgroundColor: '#F1ECEC' },
  disabledText: { fontFamily: fonts.semibold, fontSize: 12, color: colors.muted },
  mapButton: { borderWidth: 1, borderColor: colors.border, backgroundColor: colors.white },
  mapText: { fontFamily: fonts.semibold, fontSize: 14, color: colors.primaryDark },
  sourceButton: { width: 42, minHeight: 44, borderRadius: 10, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: colors.border },
  emptyBox: { alignItems: 'center', padding: 28, marginBottom: 12 },
  emptyTitle: { fontFamily: fonts.semibold, fontSize: 17, color: colors.text, marginVertical: 8 },
  disclaimer: { fontFamily: fonts.regular, fontSize: 12, color: colors.muted, paddingHorizontal: 4, paddingBottom: 12, lineHeight: 18 },
});
