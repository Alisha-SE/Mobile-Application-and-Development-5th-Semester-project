import { useContext } from 'react';
import { Alert, ScrollView, StyleSheet, Switch, Text, TouchableOpacity, View } from 'react-native';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import Field from '../components/Field';
import { BloodContext } from '../context/BloodContext';
import { checkEligibility, checkReadiness } from '../utils/eligibility';
import { colors, fonts, globalStyles } from '../styles';

const ACTIVITIES = [
  'Slept well last night',
  'Ate a proper meal',
  'Drank plenty of water',
  'Packed your ID card',
  'Read the donor guidelines',
];

export default function ProfileScreen() {
  const { profile, setProfile, checklist, setChecklist, saveProfile, saveChecklist } = useContext(BloodContext);
  async function saveBoth() {
    try { await saveProfile(); await saveChecklist(); Alert.alert('Saved', 'Profile and checklist saved in Firestore.'); }
    catch (error) { Alert.alert('Save failed', error.message); }
  }
  const { registration, canDonate } = checkEligibility(profile.age, profile.status);
  const { completion, status, ready } = checkReadiness(checklist.length, ACTIVITIES.length);

  const toggleActivity = (activity) => {
    if (checklist.includes(activity)) {
      setChecklist(checklist.filter((item) => item !== activity));
    } else {
      setChecklist([...checklist, activity]);
    }
  };

  return (
    <View style={globalStyles.screen}>
      <ScrollView contentContainerStyle={globalStyles.content} keyboardShouldPersistTaps="handled">
        <View style={globalStyles.card}>
          <Text style={globalStyles.title}>My Profile</Text>
          <Field label="Name" value={profile.name} onChangeText={(name) => setProfile({ ...profile, name })} />
          <Field
            label="Age"
            value={String(profile.age)}
            onChangeText={(age) => setProfile({ ...profile, age })}
            keyboardType="number-pad"
          />
          <Field
            label="Email"
            value={profile.email}
            editable={false}
            keyboardType="email-address"
            autoCapitalize="none"
          />
          <View style={styles.switchRow}>
            <Text style={globalStyles.body}>Active donor</Text>
            <Switch
              value={profile.status === 'active'}
              onValueChange={(on) => setProfile({ ...profile, status: on ? 'active' : 'inactive' })}
              trackColor={{ true: colors.primary }}
              accessibilityLabel="Active donor"
            />
          </View>
        </View>

        <View style={globalStyles.card}>
          <Text style={globalStyles.title}>Eligibility</Text>
          <Text style={globalStyles.body}>Age rule: {registration}</Text>
          <Text style={globalStyles.body}>Account rule: {canDonate ? 'Allowed' : 'Not Allowed'}</Text>
        </View>

        <View style={globalStyles.card}>
          <Text style={globalStyles.title}>Before You Donate</Text>
          {ACTIVITIES.map((activity, index) => {
            const checked = checklist.includes(activity);
            return (
              <TouchableOpacity
                key={activity}
                style={styles.checkRow}
                accessibilityRole="checkbox"
                aria-checked={checked}
                onPress={() => toggleActivity(activity)}
              >
                <MaterialCommunityIcons
                  name={checked ? 'checkbox-marked' : 'checkbox-blank-outline'}
                  size={26}
                  color={colors.primary}
                />
                <Text style={globalStyles.body}>
                  {index + 1}. {activity}
                </Text>
              </TouchableOpacity>
            );
          })}
          <Text style={[globalStyles.body, styles.result]}>Completion: {completion}%</Text>
          <Text style={globalStyles.body}>Status: {status}</Text>
          <Text style={globalStyles.body}>Checklist Complete: {ready ? 'Yes' : 'No'}</Text>
        </View>

        <TouchableOpacity onPress={saveBoth} style={styles.saveButton}><Text style={styles.saveText}>Save Profile & Checklist</Text></TouchableOpacity>
        <Text style={globalStyles.muted}>
          This checklist helps you prepare. The blood bank makes the final medical decision at screening.
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  switchRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 44 },
  checkRow: { flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 44 },
  result: { fontFamily: fonts.semibold, marginTop: 8 },
  saveButton: { backgroundColor: colors.primary, borderRadius: 12, alignItems: 'center', padding: 14, marginVertical: 12 },
  saveText: { color: colors.white, fontFamily: fonts.semibold },
});
