import { useContext } from 'react';
import { Alert, Linking, ScrollView, Share, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { BloodContext } from '../context/BloodContext';
import { getRequestStatus } from '../utils/requestStatus';
import { buildRequestMessage } from '../utils/shareRequest';
import { colors, fonts, globalStyles } from '../styles';

export default function SocialScreen({ navigation }) {
  const { requests } = useContext(BloodContext);
  // Share only requests where the requester explicitly enabled sharing.
  const shareable = requests.filter((item) => item.allowShare === true && getRequestStatus(item) === 'open');

  async function systemShare(request) {
    try { await Share.share({ message: buildRequestMessage(request) }); }
    catch { Alert.alert('Sharing not available', 'Please try WhatsApp or another device.'); }
  }

  async function whatsappShare(request) {
    const message = encodeURIComponent(buildRequestMessage(request));
    try { await Linking.openURL(`https://wa.me/?text=${message}`); }
    catch { Alert.alert('Unable to open WhatsApp', 'Check your browser or app.'); }
  }

  return (
    <View style={globalStyles.screen}>
      <ScrollView contentContainerStyle={globalStyles.content}>
        <View style={styles.introCard}>
          <MaterialCommunityIcons name="account-group" size={36} color={colors.primary} />
          <Text style={styles.title}>Share a Blood Request</Text>
          <Text style={globalStyles.muted}>Help a patient reach more people. Share only after the patient agrees to make their contact details public.</Text>
        </View>
        <Text style={globalStyles.title}>Open requests ({shareable.length})</Text>
        {shareable.length === 0 ? (
          <View style={globalStyles.card}>
            <Text style={styles.emptyHeading}>No shareable requests yet</Text>
            <Text style={globalStyles.muted}>Post a request and enable sharing with the patient's permission.</Text>
            <TouchableOpacity style={styles.postButton} onPress={() => navigation.navigate('Request')} accessibilityRole="button">
              <Text style={styles.postLabel}>Post a Request</Text>
            </TouchableOpacity>
          </View>
        ) : shareable.map((request) => (
          <View style={globalStyles.card} key={request.id}>
            <View style={styles.headerRow}>
              <Text style={styles.requestName}>{request.patient}</Text>
              <Text style={styles.group}>{request.group}</Text>
            </View>
            <Text style={globalStyles.body}>{request.units} unit(s) needed · {request.hospital}</Text>
            <Text style={globalStyles.muted}>Contact: {request.phone}</Text>
            <View style={styles.actions}>
              <TouchableOpacity style={styles.primaryAction} onPress={() => systemShare(request)} accessibilityRole="button">
                <MaterialCommunityIcons name="share-variant" color={colors.white} size={18} />
                <Text style={styles.whiteText}>Share</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.secondaryAction} onPress={() => whatsappShare(request)} accessibilityRole="button">
                <MaterialCommunityIcons name="whatsapp" color={colors.primaryDark} size={18} />
                <Text style={styles.redText}>WhatsApp</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
        <View style={globalStyles.card}>
          <Text style={styles.emptyHeading}>Sharing tips</Text>
          <Text style={globalStyles.body}>• Confirm the hospital and blood group.</Text>
          <Text style={globalStyles.body}>• Get permission to share the patient's contact.</Text>
          <Text style={globalStyles.body}>• Update the request when blood is arranged.</Text>
        </View>
        <Text style={styles.note}>The Social screen shares through apps installed on your phone. It is not a public social feed or live chat.</Text>
      </ScrollView>
    </View>
  );
}
const styles = StyleSheet.create({
  introCard: { backgroundColor: colors.soft, borderRadius: 16, padding: 18, marginBottom: 16, gap: 6 },
  title: { fontFamily: fonts.bold, fontSize: 21, color: colors.primaryDark },
  emptyHeading: { fontFamily: fonts.semibold, color: colors.text, fontSize: 16, marginBottom: 8 },
  postButton: { backgroundColor: colors.primary, borderRadius: 12, minHeight: 44, marginTop: 14, alignItems: 'center', justifyContent: 'center' },
  postLabel: { color: colors.white, fontFamily: fonts.semibold },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 7 },
  requestName: { fontFamily: fonts.bold, color: colors.text, fontSize: 17, flex: 1 },
  group: { fontFamily: fonts.bold, fontSize: 18, color: colors.primaryDark },
  actions: { flexDirection: 'row', gap: 8, marginTop: 12 },
  primaryAction: { backgroundColor: colors.primary, borderRadius: 11, flex: 1, minHeight: 44, alignItems: 'center', justifyContent: 'center', gap: 6, flexDirection: 'row' },
  secondaryAction: { backgroundColor: colors.white, borderRadius: 11, borderWidth: 1, borderColor: colors.border, flex: 1, minHeight: 44, alignItems: 'center', justifyContent: 'center', gap: 6, flexDirection: 'row' },
  whiteText: { fontFamily: fonts.semibold, color: colors.white },
  redText: { fontFamily: fonts.semibold, color: colors.primaryDark },
  note: { color: colors.muted, fontFamily: fonts.regular, fontSize: 12, lineHeight: 18, marginTop: 4 },
});
