import { useContext } from 'react';
import { Alert, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import StatsRow from '../components/StatsRow';
import { BloodContext } from '../context/BloodContext';
import { logoutAccount } from '../services/firebaseService';
import { colors, fonts, globalStyles } from '../styles';

const TILE_ROWS = [
  [
    { label: 'Donor', icon: 'water' },
    { label: 'Seeker', icon: 'clipboard-pulse' },
    { label: 'Request', icon: 'file-document-edit' },
  ],
  [
    { label: 'Hospital', icon: 'hospital-building' },
    { label: 'Blood Bank', icon: 'bank' },
    { label: 'Profile', icon: 'account-circle' },
  ],
  [
    { label: 'FAQ', icon: 'chat-question' },
    { label: 'Social', icon: 'account-group' },
    { label: 'My Requests', icon: 'history' },
  ],
  [
    { label: 'Availability', icon: 'toggle-switch' },
    { label: 'City Lookup', icon: 'map-search' },
  ],
];

export default function HomeScreen({ navigation }) {
  const { user, profile } = useContext(BloodContext);
  async function logout() {
    try { await logoutAccount(); } catch (error) { Alert.alert('Logout failed', error.message); }
  }
  return (
    <SafeAreaView style={globalStyles.screen}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.banner}>
          <MaterialCommunityIcons name="hand-heart" size={64} color={colors.white} />
          <View style={styles.bannerText}>
            <Text style={styles.bannerTitle}>Blood Donation</Text>
            <Text style={styles.bannerSubtitle}>Donate Blood, Save Lives</Text>
          </View>
        </View>

        <TouchableOpacity style={styles.accountLink} onPress={logout} accessibilityRole="button">
          <MaterialCommunityIcons name="account-outline" size={18} color={colors.primaryDark} />
          <Text style={styles.accountText}>{profile.name || user?.email || 'Account'} · Log out</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.urgentLink} accessibilityRole="button" onPress={() => navigation.push('Request', { startUrgent: true })}>
          <MaterialCommunityIcons name="alert-circle" size={22} color={colors.white} />
          <Text style={styles.urgentLinkText}>Need blood urgently? Post Emergency Request</Text>
        </TouchableOpacity>
        <Text style={styles.heading}>Blood Donor</Text>
        <Text style={styles.subheading}>How can we help you today?</Text>

        {TILE_ROWS.map((row, index) => (
          <View key={index} style={[styles.tileRow, row.length === 2 && styles.shortRow]}>
            {row.map((tile) => (
              <TouchableOpacity
                key={tile.label}
                style={[styles.tile, row.length === 1 && styles.singleTile]}
                accessibilityRole="button"
                onPress={() => navigation.navigate(tile.label)}
              >
                <MaterialCommunityIcons name={tile.icon} size={44} color={colors.primary} />
                <Text style={styles.tileLabel}>{tile.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        ))}

        <StatsRow />

        <View style={styles.footer}>
          <MaterialCommunityIcons name="heart-pulse" size={32} color={colors.white} />
          <Text style={styles.footerText}>Find a donor, save a life.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: 24 },
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.primary,
    borderRadius: 20,
    paddingHorizontal: 20,
    paddingVertical: 24,
  },
  bannerText: { flex: 1 },
  bannerTitle: { fontFamily: fonts.bold, fontSize: 28, color: colors.white },
  bannerSubtitle: { fontFamily: fonts.regular, fontSize: 15, color: colors.white, marginTop: 4 },
  accountLink: { flexDirection: 'row', justifyContent: 'center', gap: 7, alignItems: 'center', marginTop: 14 },
  accountText: { fontFamily: fonts.semibold, fontSize: 13, color: colors.primaryDark },
  heading: { fontFamily: fonts.bold, fontSize: 30, color: colors.primaryDark, textAlign: 'center', marginTop: 16 },
  subheading: { fontFamily: fonts.regular, fontSize: 15, color: colors.muted, textAlign: 'center', marginBottom: 12 },
  tileRow: { flexDirection: 'row', gap: 10, paddingHorizontal: 16, marginBottom: 10 },
  shortRow: { paddingHorizontal: 44 },
  tile: { flex: 1, alignItems: 'center', gap: 8, backgroundColor: colors.card, borderRadius: 16, paddingVertical: 16 },
  singleTile: { flex: 0, width: '31%' },
  tileLabel: { fontFamily: fonts.semibold, fontSize: 14, color: colors.text },
  urgentLink: { marginTop: 12, marginHorizontal: 16, borderRadius: 12, backgroundColor: colors.primaryDark, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, padding: 13 },
  urgentLinkText: { flex: 1, fontFamily: fonts.semibold, color: colors.white, fontSize: 13 },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.primary,
    borderRadius: 16,
    marginHorizontal: 16,
    marginTop: 12,
    padding: 16,
  },
  footerText: { fontFamily: fonts.semibold, fontSize: 15, color: colors.white },
});
