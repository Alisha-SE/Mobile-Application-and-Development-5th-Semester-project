import { useEffect, useState } from 'react';
import { Alert, FlatList, Linking, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { BLOOD_BANKS } from '../data/bloodBanks';
import { filterBloodBanks } from '../utils/bloodBankSearch';
import { colors, fonts, globalStyles } from '../styles';

const CITIES = ['All', 'Islamabad', 'Rawalpindi'];

async function openLink(url) {
  try { await Linking.openURL(url); }
  catch { Alert.alert('Could not open', 'Check your phone or internet connection.'); }
}

export default function BloodBankScreen({ navigation }) {
  const [query, setQuery] = useState('');
  const [city, setCity] = useState('All');
  const results = filterBloodBanks(BLOOD_BANKS, query, city);

  useEffect(() => {
    navigation.setOptions({ title: `Blood Banks (${results.length})` });
  }, [navigation, results.length]);

  function showLocation(item) {
    const search = encodeURIComponent(`${item.name}, ${item.address}`);
    openLink(`https://www.google.com/maps/search/?api=1&query=${search}`);
  }

  return (
    <View style={globalStyles.screen}>
      <FlatList
        data={results}
        keyExtractor={(item) => item.id}
        contentContainerStyle={globalStyles.content}
        keyboardShouldPersistTaps="handled"
        ListHeaderComponent={
          <View>
            <Text style={styles.heading}>Find a Blood Bank</Text>
            <Text style={globalStyles.muted}>Contact a centre before visiting.</Text>
            <View style={styles.searchBox}>
              <MaterialCommunityIcons name="magnify" size={21} color={colors.muted} />
              <TextInput accessibilityLabel="Search blood banks" placeholder="Search name or area" placeholderTextColor={colors.muted} style={styles.input} value={query} onChangeText={setQuery} />
            </View>
            <View style={styles.cityRow}>
              {CITIES.map((option) => (
                <TouchableOpacity key={option} style={[styles.chip, option === city && styles.selectedChip]} onPress={() => setCity(option)} accessibilityRole="button">
                  <Text style={[styles.chipText, option === city && styles.selectedText]}>{option}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <Text style={styles.count}>{results.length} blood bank(s) found</Text>
          </View>
        }
        ListEmptyComponent={<Text style={globalStyles.muted}>No blood banks found. Try another name or city.</Text>}
        renderItem={({ item }) => (
          <View style={globalStyles.card}>
            <View style={styles.row}>
              <MaterialCommunityIcons name="water" color={colors.primary} size={29} />
              <View style={{ flex: 1 }}>
                <Text style={styles.name}>{item.name}</Text>
                <Text style={globalStyles.muted}>{item.type} · {item.city}</Text>
              </View>
            </View>
            <Text style={globalStyles.body}>{item.address}</Text>
            <Text style={globalStyles.muted}>Phone: {item.phone}</Text>
            <View style={styles.actions}>
              <TouchableOpacity accessibilityRole="button" style={[styles.action, styles.primary]} onPress={() => openLink(`tel:${item.phone}`)}>
                <MaterialCommunityIcons name="phone" color={colors.white} size={18} />
                <Text style={styles.whiteText}>Call</Text>
              </TouchableOpacity>
              <TouchableOpacity accessibilityRole="button" style={styles.action} onPress={() => showLocation(item)}>
                <MaterialCommunityIcons name="map-marker" color={colors.primaryDark} size={18} />
                <Text style={styles.redText}>Location</Text>
              </TouchableOpacity>
              <TouchableOpacity accessibilityRole="button" accessibilityLabel={`View source for ${item.name}`} style={styles.source} onPress={() => openLink(item.sourceUrl)}>
                <MaterialCommunityIcons name="open-in-new" color={colors.primaryDark} size={20} />
              </TouchableOpacity>
            </View>
          </View>
        )}
        ListFooterComponent={
          <Text style={styles.note}>Directory only — blood stock is NOT live. Call to confirm blood availability, donor requirements and opening hours. Details may change.</Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  heading: { fontFamily: fonts.bold, fontSize: 22, color: colors.primaryDark, marginBottom: 5 },
  searchBox: { backgroundColor: colors.white, borderRadius: 12, borderWidth: 1, borderColor: colors.border, marginTop: 14, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 8 },
  input: { flex: 1, paddingVertical: 12, fontFamily: fonts.regular, color: colors.text },
  cityRow: { flexDirection: 'row', gap: 8, marginVertical: 12 },
  chip: { borderRadius: 10, backgroundColor: colors.white, borderColor: colors.border, borderWidth: 1, paddingHorizontal: 12, minHeight: 42, alignItems: 'center', justifyContent: 'center' },
  selectedChip: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { fontFamily: fonts.semibold, fontSize: 13, color: colors.text },
  selectedText: { color: colors.white },
  count: { color: colors.muted, fontFamily: fonts.semibold, marginBottom: 10 },
  row: { flexDirection: 'row', gap: 10, alignItems: 'flex-start', marginBottom: 10 },
  name: { fontFamily: fonts.bold, fontSize: 16, color: colors.text, marginBottom: 4 },
  actions: { flexDirection: 'row', gap: 8, marginTop: 12, alignItems: 'center' },
  action: { backgroundColor: colors.white, borderColor: colors.border, borderWidth: 1, borderRadius: 10, flex: 1, flexDirection: 'row', minHeight: 44, alignItems: 'center', justifyContent: 'center', gap: 5 },
  primary: { backgroundColor: colors.primary, borderColor: colors.primary },
  whiteText: { color: colors.white, fontFamily: fonts.semibold },
  redText: { color: colors.primaryDark, fontFamily: fonts.semibold },
  source: { borderColor: colors.border, borderWidth: 1, borderRadius: 10, width: 43, minHeight: 44, alignItems: 'center', justifyContent: 'center' },
  note: { marginTop: 8, color: colors.muted, fontFamily: fonts.regular, fontSize: 12, lineHeight: 18 },
});
