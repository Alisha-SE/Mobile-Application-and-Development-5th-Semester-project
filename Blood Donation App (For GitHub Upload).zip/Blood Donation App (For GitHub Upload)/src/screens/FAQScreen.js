import { useState } from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { colors, fonts, globalStyles } from '../styles';

const FAQS = [
  { question: 'How do I register as a donor?', answer: 'Open Donor, fill in the form, choose your blood group and tap Register.' },
  { question: 'How can I search for donors?', answer: 'Open Seeker, select the patient blood group and optionally type a city.' },
  { question: 'How do I post a blood request?', answer: 'Open Request, enter the patient and hospital details, then tap Post Request.' },
  { question: 'Where is my data saved?', answer: 'Your account and donor/request records are stored in Firebase Authentication and Cloud Firestore after you sign in.' },
  { question: 'Can I find hospitals and blood banks?', answer: 'Yes. Open Hospital or Blood Bank to browse a local contact directory. Availability is not live; call ahead.' },
  { question: 'Can I share a blood request?', answer: 'Yes. Post your request, then open Social to share an open request with WhatsApp or your phone share sheet. Ask the patient before sharing contact details.' },
  { question: 'Do I need an account?', answer: 'Yes. Create an account or sign in with email/password using Firebase Authentication.' },
  { question: 'Does the app verify medical eligibility?', answer: 'No. Blood group matching and readiness are educational examples. A qualified blood bank must perform medical screening and compatibility testing.' },
];

export default function FAQScreen() {
  const [opened, setOpened] = useState(-1);
  return (
    <View style={globalStyles.screen}>
      <ScrollView contentContainerStyle={globalStyles.content}>
        <Text style={globalStyles.title}>Frequently Asked Questions</Text>
        {FAQS.map((faq, index) => (
          <View style={globalStyles.card} key={faq.question}>
            <TouchableOpacity accessibilityRole="button" onPress={() => setOpened(opened === index ? -1 : index)}>
              <Text style={styles.question}>{faq.question} {opened === index ? '−' : '+'}</Text>
            </TouchableOpacity>
            {opened === index ? <Text style={globalStyles.body}>{faq.answer}</Text> : null}
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  question: { fontFamily: fonts.semibold, fontSize: 15, color: colors.primaryDark, marginBottom: 6 },
});
