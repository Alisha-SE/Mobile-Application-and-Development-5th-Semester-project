import { createContext, useEffect, useState } from 'react';
import { firebaseConfigured } from '../firebase/config';
import {
  createBloodRequest, createDonor, listenToAuth, listenToCollection, listenToMyProfile,
  saveUserChecklist, saveUserProfile, updateBloodRequestStatus, updateDonorAvailability,
} from '../services/firebaseService';

export const BloodContext = createContext(null);
const EMPTY_PROFILE = { name: '', age: '', email: '', status: 'active' };
export function BloodProvider({ children }) {
  const [user, setUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [donors, setDonors] = useState([]);
  const [requests, setRequests] = useState([]);
  const [profile, setProfile] = useState(EMPTY_PROFILE);
  const [checklist, setChecklist] = useState([]);
  const [dataError, setDataError] = useState('');

  useEffect(() => {
    if (!firebaseConfigured) { setAuthLoading(false); return; }
    return listenToAuth((nextUser) => {
      setUser(nextUser);
      setAuthLoading(false);
    }, (error) => { setDataError(error.message); setAuthLoading(false); });
  }, []);

  useEffect(() => {
    if (!user) {
      setDonors([]); setRequests([]); setProfile(EMPTY_PROFILE); setChecklist([]);
      return;
    }
    const onError = (error) => setDataError(error.message || 'Unable to access Firestore. Check database rules.');
    const offDonors = listenToCollection('donors', setDonors, onError);
    const offRequests = listenToCollection('requests', setRequests, onError);
    const offProfile = listenToMyProfile(user.uid, (record) => {
      setProfile({ name: record.name || '', age: record.age || '',
        email: record.email || user.email || '', status: record.status || 'active' });
      setChecklist(Array.isArray(record.checklist) ? record.checklist : []);
    }, onError);
    return () => { offDonors(); offRequests(); offProfile(); };
  }, [user?.uid]);

  function requireUser() {
    if (!user) throw new Error('Please log in first.');
    return user.uid;
  }
  async function addDonor(donor) {
    return createDonor(donor, requireUser());
  }
  async function addRequest(request) {
    return createBloodRequest(request, requireUser());
  }
  async function changeRequestStatus(id, status) {
    const uid = requireUser();
    if (!requests.some((r) => r.id === id && r.ownerUid === uid)) throw new Error('Only your own requests can be changed.');
    return updateBloodRequestStatus(id, status);
  }
  async function changeDonorAvailability(id, available) {
    const uid = requireUser();
    if (!donors.some((d) => d.id === id && d.ownerUid === uid)) throw new Error('Only your own donor records can be changed.');
    return updateDonorAvailability(id, available);
  }
  async function saveProfile() { return saveUserProfile(requireUser(), profile); }
  async function saveChecklist() { return saveUserChecklist(requireUser(), checklist); }

  return <BloodContext.Provider value={{
    user, authLoading, firebaseConfigured, dataError, setDataError,
    donors, requests, profile, setProfile, checklist, setChecklist,
    addDonor, addRequest, changeRequestStatus, changeDonorAvailability,
    saveProfile, saveChecklist,
  }}>{children}</BloodContext.Provider>;
}
