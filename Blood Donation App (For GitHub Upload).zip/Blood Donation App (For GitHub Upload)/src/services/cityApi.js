// Lecture 11: real HTTP GET request with fetch(), JSON parsing and error handling.
// Open-Meteo Geocoding API: https://open-meteo.com/en/docs/geocoding-api
export async function searchPakistaniCities(query, request = fetch) {
  const name = String(query || '').trim();
  if (name.length < 2) return [];
  const url = 'https://geocoding-api.open-meteo.com/v1/search?name=' +
    encodeURIComponent(name) + '&count=8&language=en&format=json&countryCode=PK';
  const response = await request(url);
  if (!response.ok) throw new Error('City service unavailable. Try again online.');
  const json = await response.json();
  if (json.error) throw new Error(json.reason || 'City service error');
  return (json.results || []).filter((result) => result.country_code === 'PK').map((result) => ({
    id: result.id, name: result.name, region: result.admin1 || '', country: result.country,
    latitude: result.latitude, longitude: result.longitude,
  }));
}
