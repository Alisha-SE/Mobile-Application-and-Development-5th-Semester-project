# Backend and API services

- `firebaseService.js` implements real Firebase Email/Password signup/login, profile reads and updates, donor reads/writes, and blood request reads/writes and status updates.
- `cityApi.js` uses the JavaScript `fetch()` HTTP GET API to look up cities in Pakistan with the Open-Meteo geocoding service.

Firebase requires your **own** web app configuration in `.env`, the Email/Password sign-in provider, Firestore database, and published `firestore.rules`. See `FIREBASE_SETUP_ROMAN_URDU.md` in the project root.
