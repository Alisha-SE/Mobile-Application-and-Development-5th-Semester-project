import { createUserWithEmailAndPassword, onAuthStateChanged, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { addDoc, collection, doc, onSnapshot, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { firebaseAuth, firestore } from '../firebase/config';

// Alisha: Firebase Authentication + profile write/update.
export const listenToAuth = (onUser, onError) => onAuthStateChanged(firebaseAuth, onUser, onError);
export async function registerAccount({ name, email, password, role }) {
  const result = await createUserWithEmailAndPassword(firebaseAuth, email.trim(), password);
  await setDoc(doc(firestore, 'users', result.user.uid), {
    name: name.trim(), email: result.user.email, role,
    age: '', status: 'active', checklist: [],
  });
  return result.user;
}
export async function loginAccount(email, password) {
  return (await signInWithEmailAndPassword(firebaseAuth, email.trim(), password)).user;
}
export const logoutAccount = () => signOut(firebaseAuth);
export function listenToMyProfile(uid, onProfile, onError) {
  return onSnapshot(doc(firestore, 'users', uid), (snap) => {
    if (snap.exists()) onProfile(snap.data());
  }, onError);
}
export async function saveUserProfile(uid, profile) {
  return setDoc(doc(firestore, 'users', uid), {
    name: String(profile.name || '').trim(), age: String(profile.age || ''),
    status: profile.status === 'inactive' ? 'inactive' : 'active',
  }, { merge: true });
}
export async function saveUserChecklist(uid, items) {
  return updateDoc(doc(firestore, 'users', uid), { checklist: items });
}

// Bibi Zahra: Firestore reads/writes for donors and requests.
export function listenToCollection(collectionName, onData, onError) {
  return onSnapshot(collection(firestore, collectionName), (snapshot) => {
    const list = snapshot.docs.map((item) => ({ ...item.data(), id: item.id }));
    onData(list);
  }, onError);
}
export async function createDonor(data, uid) {
  return addDoc(collection(firestore, 'donors'), {
    ...data, ownerUid: uid, status: 'active', available: true, createdAt: serverTimestamp(),
  });
}
export async function createBloodRequest(data, uid) {
  return addDoc(collection(firestore, 'requests'), {
    ...data, ownerUid: uid, status: 'open',
    urgent: data.urgent === true,
    allowShare: data.allowShare === true,
    createdAt: serverTimestamp(),
  });
}
export async function updateDonorAvailability(id, available) {
  return updateDoc(doc(firestore, 'donors', id), { available: Boolean(available) });
}
export async function updateBloodRequestStatus(id, status) {
  if (!['open', 'fulfilled'].includes(status)) throw new Error('Invalid request status');
  return updateDoc(doc(firestore, 'requests', id), { status });
}
