// A small, manually checked directory for the semester project.
// This is NOT a live blood-stock database. Contact numbers can change.
// Sources and check date are documented in HOSPITAL_SOURCES.md.
export const HOSPITALS = [
  {
    id: 'shifa',
    name: 'Shifa International Hospital',
    city: 'Islamabad',
    address: 'Pitras Bukhari Road, H-8/4, Islamabad, Pakistan',
    phone: '0518464646',
    category: 'Private hospital',
    sourceUrl: 'https://www.shifa.com.pk/contact-us',
  },
  {
    id: 'pims',
    name: 'Pakistan Institute of Medical Sciences (PIMS)',
    city: 'Islamabad',
    address: 'Ibn-e-Sina Road, G-8/3, Islamabad, Pakistan',
    phone: '0519261170',
    category: 'Government hospital',
    sourceUrl: 'https://www.gov.uk/government/publications/pakistan-list-of-medical-facilities/list-of-english-speaking-doctors-in-pakistan',
  },
  {
    id: 'holy-family',
    name: 'Holy Family Hospital',
    city: 'Rawalpindi',
    address: 'Holy Family Road, Satellite Town, Rawalpindi, Pakistan',
    phone: '0519290359',
    category: 'Government hospital',
    sourceUrl: 'https://www.gov.uk/government/publications/pakistan-list-of-medical-facilities/list-of-english-speaking-doctors-in-pakistan',
  },
  {
    id: 'maryam-memorial',
    name: 'Maryam Memorial Hospital (Peshawar Road)',
    city: 'Rawalpindi',
    address: 'Main Peshawar Road, Rawalpindi, Pakistan',
    phone: '0515481170',
    category: 'Private hospital',
    sourceUrl: 'https://www.maryammemorialhospital.com/contact1',
  },
  {
    id: 'benazir-bhutto',
    name: 'Benazir Bhutto Hospital',
    city: 'Rawalpindi',
    address: 'Near Chandni Chowk, Murree Road, Rawalpindi, Pakistan',
    phone: null, // No phone number confirmed from the hospital's official page.
    category: 'Government hospital',
    sourceUrl: 'https://rmur.edu.pk/benazir-bhutto-hospital/',
  },
];
