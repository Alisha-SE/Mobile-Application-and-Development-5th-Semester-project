// Offline directory. Facilities/contacts are references only, NOT live blood stock.
// Information sources are documented in BLOOD_BANK_SOURCES.md.
export const BLOOD_BANKS = [
  {
    id: 'prcs-islamabad',
    name: 'Pakistan Red Crescent Blood Donor Centre',
    city: 'Islamabad',
    address: 'Ashfaq Ahmed Road, H-8/2, Islamabad, Pakistan',
    phone: '0519250412',
    type: 'Blood donor centre / laboratory',
    sourceUrl: 'https://prcs.org.pk/lab',
  },
  {
    id: 'shifa-bank',
    name: 'Shifa International Hospital Blood Bank',
    city: 'Islamabad',
    address: 'Pitras Bukhari Road, H-8/4, Islamabad, Pakistan',
    phone: '0518464646',
    type: 'Hospital blood bank · hospital main line',
    sourceUrl: 'https://www.shifa.com.pk/contact-us',
  },
  {
    id: 'pims-bank',
    name: 'PIMS Blood Bank',
    city: 'Islamabad',
    address: 'Ibn-e-Sina Road, G-8/3, Islamabad, Pakistan',
    phone: '0519261170',
    type: 'Hospital blood bank · hospital main line',
    sourceUrl: 'https://www.gov.uk/government/publications/pakistan-list-of-medical-facilities/list-of-english-speaking-doctors-in-pakistan',
  },
  {
    id: 'alpha-rawalpindi',
    name: 'Alpha Blood Center',
    city: 'Rawalpindi',
    address: 'Wega 99 Tower, near Holy Family Hospital Gate 2, Satellite Town, Rawalpindi, Pakistan',
    phone: '0514801066',
    type: 'Blood bank',
    sourceUrl: 'https://www.google.com/maps/search/?api=1&query=Alpha%20Blood%20Center%20Rawalpindi',
  },
];
