import { useContext } from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import { useFonts, Inter_400Regular, Inter_600SemiBold, Inter_700Bold } from '@expo-google-fonts/inter';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { BloodContext, BloodProvider } from './src/context/BloodContext';
import SetupRequiredScreen from './src/screens/SetupRequiredScreen';
import LoginScreen from './src/screens/LoginScreen';
import SignupScreen from './src/screens/SignupScreen';
import HomeScreen from './src/screens/HomeScreen';
import DonorScreen from './src/screens/DonorScreen';
import SeekerScreen from './src/screens/SeekerScreen';
import DonorDetailScreen from './src/screens/DonorDetailScreen';
import RequestScreen from './src/screens/RequestScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import HospitalScreen from './src/screens/HospitalScreen';
import BloodBankScreen from './src/screens/BloodBankScreen';
import FAQScreen from './src/screens/FAQScreen';
import SocialScreen from './src/screens/SocialScreen';
import MyRequestsScreen from './src/screens/MyRequestsScreen';
import AvailabilityScreen from './src/screens/AvailabilityScreen';
import CityLookupScreen from './src/screens/CityLookupScreen';
import { colors, fonts } from './src/styles';
const Stack = createNativeStackNavigator();
const screenOptions = {headerStyle:{backgroundColor:colors.primary},headerTintColor:colors.white,headerTitleStyle:{fontFamily:fonts.semibold}};
function MainNavigation() {
  const { user, authLoading, firebaseConfigured, dataError } = useContext(BloodContext);
  if (!firebaseConfigured) return <SetupRequiredScreen/>;
  if (authLoading) return <View style={{flex:1,justifyContent:'center'}}><ActivityIndicator color={colors.primary} size="large"/></View>;
  return <NavigationContainer><StatusBar style="dark"/>
    <Stack.Navigator screenOptions={screenOptions}>
      {user ? <>
        <Stack.Screen name="Home" component={HomeScreen} options={{headerShown:false}}/>
        <Stack.Screen name="Donor" component={DonorScreen}/>
        <Stack.Screen name="Seeker" component={SeekerScreen}/>
        <Stack.Screen name="DonorDetail" component={DonorDetailScreen} options={{title:'Donor Details'}}/>
        <Stack.Screen name="Request" component={RequestScreen}/>
        <Stack.Screen name="Profile" component={ProfileScreen}/>
        <Stack.Screen name="Hospital" component={HospitalScreen}/>
        <Stack.Screen name="Blood Bank" component={BloodBankScreen}/>
        <Stack.Screen name="FAQ" component={FAQScreen}/>
        <Stack.Screen name="Social" component={SocialScreen}/>
        <Stack.Screen name="My Requests" component={MyRequestsScreen}/>
        <Stack.Screen name="Availability" component={AvailabilityScreen} options={{title:'Donor Availability'}}/>
        <Stack.Screen name="City Lookup" component={CityLookupScreen}/>
      </> : <>
        <Stack.Screen name="Login" component={LoginScreen} options={{title:'Log In'}}/>
        <Stack.Screen name="Signup" component={SignupScreen} options={{title:'Sign Up'}}/>
      </>}
    </Stack.Navigator>
    {!!dataError && <View style={{backgroundColor:colors.soft,padding:6}}><Text style={{color:colors.primaryDark,fontSize:11,textAlign:'center'}}>{dataError}</Text></View>}
  </NavigationContainer>;
}
export default function App() {
  const [loaded,fontError] = useFonts({Inter_400Regular,Inter_600SemiBold,Inter_700Bold});
  if(!loaded&&!fontError)return null;
  return <SafeAreaProvider><BloodProvider><MainNavigation/></BloodProvider></SafeAreaProvider>;
}
