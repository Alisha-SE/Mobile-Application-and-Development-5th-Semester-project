
# Blood Donation App

## Short Description

The Blood Donation App is a mobile application developed using React Native and Expo. It connects blood donors with blood seekers and helps users find potential blood donors during emergencies.

The application provides donor registration, advanced donor search, emergency blood requests, hospital and blood bank directories, donor availability management, user profiles, request history, and city lookup using the Fetch API.

## Firebase Features Used

### Firebase Authentication

- User account registration
- User login using email and password
- User logout
- User authentication and session management

### Cloud Firestore

- Store and retrieve user profiles
- Register and retrieve blood donor records
- Create and retrieve blood requests
- Update donor availability
- Update blood request status
- Manage blood request history

## GitHub Repository Link

[Blood Donation App - GitHub Repository](https://github.com/Alisha-SE/Mobile-Application-and-Development-5th-Semester-project)
